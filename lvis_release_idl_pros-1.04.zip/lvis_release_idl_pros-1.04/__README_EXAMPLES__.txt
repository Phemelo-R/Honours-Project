The read_lvis_release.pro program will call the detection routine, and
determine the file type to load.

You can pass the file name or just run the reader with a variable as the
arguement to pull up a dialog box.

read_lvis_release,l

alternatively:

read_lvis_release,l,FILE='VECT_20081120/LVIS_US_CA_day1_2008_VECT_20081120.lce.1.03'

you can also force the records to read and the version number with these
example tags:

RECORDS=100
VERSIONS=1.03

read_lvis_release,l,FILE='LVIS_US_CA_day1_2008_VECT_20081120.lce.1.03',RECORDS=100
read_lvis_release,l,FILE='LVIS_US_CA_day1_2008_VECT_20081120.lce.1.03',VERSIONS=1.03

or you can use the functions directly if you want to manually pick the
version and file type:

read_lce_v1,lce,FILE='LVIS_US_CA_day1_2008_VECT_20081120.lce.1.03'
read_lge_v1,lge,FILE='LVIS_US_CA_day1_2008_VECT_20081120.lge.1.03'
read_lgw_v1,lgw,FILE='LVIS_US_CA_day1_2008_WAVE_20081120.lgw.1.03'



